

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

// Signal handler for SIGINT
void handle_sigint(int sig) {
    printf("SIGINT signal caught!\n");
    exit(0); 
}

int main() {
    if (signal(SIGINT, handle_sigint) == SIG_ERR) {
        perror("Error setting up signal handler");
        return 1;
    }


    printf("Waiting for SIGINT signal (press Ctrl+C)...\n");
    while (1) {
        sleep(1); // Sleep for 1 second to avoid using too much CPU
    }

    return 0;
}
