#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

static int sigint_count = 0;

// Custom signal handler
void sigint_handler(int sig) {
    sigint_count++;
    
    // Display the signal number and message
    printf("Caught signal %d (SIGINT). This is the %d time.\n", sig, sigint_count);
    
    // After the second signal, restore default behavior and terminate
    if (sigint_count == 2) {
        // Restore default behavior for SIGINT
        signal(SIGINT, SIG_DFL);
        printf("Restoring default SIGINT behavior. Program will terminate on next SIGINT.\n");
    }
}

int main() {
    // Register the custom handler for SIGINT
    if (signal(SIGINT, sigint_handler) == SIG_ERR) {
        perror("Unable to register signal handler");
        exit(1);
    }

    
    printf("Running... Press Ctrl+C to send SIGINT.\n");
    
    while (1) {
        // Sleep for a while to allow SIGINT to be received
        sleep(1);
    }

    return 0;
}
